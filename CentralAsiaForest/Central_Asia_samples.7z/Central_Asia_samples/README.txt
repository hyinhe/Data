This folder contains training and validation samples compiled by Yin et al. (2017)

Class code:
11: Deciduous forest
12: Mixed forest
13: Evergreen forest
21: herbaceous land (including grassland and cropland),
31: barren land
41: water bodies 
51: non-woody wetland

Validation shapefile: 

confi: 0: confident; 1: not confident. The non-confident pixels are mainly the ones that are hard to lable because of the lack of high resolution data.
mixed: 0: mixed pixel; 1: unmixed pixel

Citation: Yin, H. Khamzina, A. Pflugmacher, D. and Martius, C. (2017): Forest cover mapping in post-Soviet Central Asia using multi-resolution remote sensing imagery. Scientific Reports. 7:1375